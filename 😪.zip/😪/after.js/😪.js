const axios = require('axios');
const { cmd } = require('../lib/bot');
const bot = require('../lib/bot');
const config = require('../config');
const NodeCache = require('node-cache');
const movieCache = new NodeCache({ stdTTL: 100, checkperiod: 120 });

cmd({
    pattern: 'movie',
    alias: ['moviedl'],
    desc: 'Search and download movies (multiple links)',
    category: 'downloads',
    react: '🎬',
    filename: __filename
}, async (client, message, args, { from, q, contextInfo }) => {
    if (!q) return await client.sendMessage(from, { text: 'Please provide a movie name.' }, { quoted: message });

    const query = q.trim().toLowerCase();
    let cached = movieCache.get(query);
    if (!cached) {
        const apiUrl = `https://pupil-eta.vercel.app/search?q=${encodeURIComponent(query)}`;
        const response = await axios.get(apiUrl);
        cached = response.data;
        if (!cached || !cached.status || !cached.result) throw new Error('No movies found.');
        movieCache.set(query, cached);
    }

    const movies = cached.result.map((item, index) => ({
        number: index + 1,
        title: item.title,
        published: item.published,
        author: item.author,
        tag: item.tag,
        link: item.link
    }));

    let listMessage = '🎬 *MOVIE RESULTS*\n\n';
    movies.forEach(m => {
        listMessage += `*${m.number}.* ${m.title}\n`;
    });

    const sentMsg = await client.sendMessage(from, {
        image: { url: bot.logo },
        caption: listMessage + '\nReply with the number to download.'
    }, { quoted: message });

    // Event handler for number replies
    const selectionMap = new Map();
    const handler = async (msg) => {
        // ... handle reply logic
    };
    client.ev.on('messages.upsert', handler);
    setTimeout(() => client.ev.off('messages.upsert', handler), 60000);
});